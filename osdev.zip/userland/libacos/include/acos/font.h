#pragma once
#include <acos/types.h>
#include <acos/span.h>

namespace acos::graphics {

struct PSF1Header {
    u16 magic;
    u8 mode;
    u8 charsize;
};

struct PSF2Header {
    u32 magic;
    u32 version;
    u32 headersize;
    u32 flags;
    u32 length;
    u32 charsize;
    u32 height;
    u32 width;
};

class Font {
public:
    enum class Style {
        Regular = 0,
        Bold = 1,
        Italic = 2
    };

    enum class Alignment {
        Left,
        Center,
        Right
    };

    Font() : m_valid(false), m_width(0), m_height(0), m_charsize(0), m_headersize(0), m_data(nullptr), m_data_size(0), m_is_psf2(false), m_is_ttf(false), m_glyph_alpha(nullptr) {}
    Font(const u8* data, usize size);
    Font(acos::Span<const u8> data) : Font(data.data(), data.size()) {}

    bool is_valid() const { return m_valid; }
    u32 width() const { return m_width; }
    u32 height() const { return m_height; }
    u32 char_size() const { return m_charsize; }
    bool is_ttf() const { return m_is_ttf; }

    u32 get_char_width(char c) const;

    const u8* get_glyph(char c) const;

    // For TrueType fonts only: raw 0-255 stb_truetype coverage values,
    // one byte per pixel, for antialiased drawing (see Renderer::draw_text).
    const u8* get_glyph_alpha(char c) const;

private:
    bool m_valid;
    u32 m_width;
    u32 m_height;
    u32 m_charsize;
    u32 m_headersize;
    const u8* m_data;
    [[maybe_unused]] usize m_data_size;
    bool m_is_psf2;
    bool m_is_ttf;
    // One 0-255 coverage byte per pixel, per glyph, in an 8x16 cell.
    // Real grayscale coverage (not thresholded) so text can be antialiased.
    u8* m_glyph_alpha;
    u8 m_glyph_widths[256];
};

} // namespace acos::graphics
