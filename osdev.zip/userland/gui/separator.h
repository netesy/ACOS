#pragma once
#include "widget.h"
#include "scrollbar.h"

namespace acos::gui::widgets {

class Separator : public Widget {
public:
    Ref<RenderObject> create_render_object() override;
    Separator(Orientation orient = Orientation::Horizontal);
    virtual ~Separator();

private:
    [[maybe_unused]] Orientation m_orientation;
};

} // namespace acos::gui::widgets
