#pragma once
#include "button.h"

namespace acos::gui::widgets {

class ToolButton : public Button {
public:
    Ref<RenderObject> create_render_object() override;
    ToolButton(const char* label = nullptr);
    virtual ~ToolButton();
};

} // namespace acos::gui::widgets
